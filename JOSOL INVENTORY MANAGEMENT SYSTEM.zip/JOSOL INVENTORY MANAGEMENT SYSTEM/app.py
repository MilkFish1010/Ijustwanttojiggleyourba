from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

# Database functions
def start():
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS inventory (
                        id INTEGER PRIMARY KEY,
                        product_name TEXT NOT NULL,
                        quantity INTEGER NOT NULL)''')
    conn.commit()
    conn.close()

def add_or_update_product(product_name, quantity):
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id, quantity FROM inventory WHERE product_name = ?', (product_name,))
    product = cursor.fetchone()

    if product:
        new_quantity = round(product[1] + quantity, 2)  # Add/Subtract and round to 2 decimal places
        if new_quantity <= 0:
            cursor.execute('DELETE FROM inventory WHERE id = ?', (product[0],))  
        else:
            cursor.execute('UPDATE inventory SET quantity = ? WHERE id = ?', (new_quantity, product[0]))
    else:
        if quantity > 0:
            cursor.execute('INSERT INTO inventory (product_name, quantity) VALUES (?, ?)', (product_name, quantity))
    
    conn.commit()
    conn.close()


def remove_product(product_name):
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM inventory WHERE product_name = ?', (product_name,))
    conn.commit()
    conn.close()

def clear_inventory():
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM inventory')
    conn.commit()
    conn.close()

def get_product_list():
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM inventory')
    products = cursor.fetchall()
    conn.close()
    return products

# pie chart
def get_inventory_statistics():
    conn = sqlite3.connect('inventory.db')
    cursor = conn.cursor()
    cursor.execute('SELECT product_name, quantity FROM inventory')
    products = cursor.fetchall()
    conn.close()
    return products


def generate_pie_chart():
    products = get_inventory_statistics()
    names = [product[0] for product in products]
    quantities = [product[1] for product in products]

    fig, ax = plt.subplots()
    fig.set_facecolor('#b77539') 
    ax.set_facecolor('white') 

    ax.pie(quantities, labels=names, autopct='%1.1f%%', startangle=90)
    ax.axis('equal')

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight')
    buf.seek(0)
    chart = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()

    return chart

# Create table when the application starts
start()

@app.route('/')
def index():
    products = get_product_list()
    chart = generate_pie_chart()
    return render_template('index.html', products=products, chart=chart)

@app.route('/add', methods=['POST'])
def add():
    product_name = request.form['product_name']
    try:
        quantity = float(request.form['quantity'])  # Convert to float
        add_or_update_product(product_name, quantity)
    except ValueError:
        print("Invalid quantity. Please enter a valid number.")  # Handle invalid input
    return redirect(url_for('index'))



@app.route('/remove', methods=['POST'])
def remove():
    product_name = request.form['product_name']
    if product_name:
        remove_product(product_name)
    return redirect(url_for('index'))

@app.route('/clear', methods=['POST'])
def clear():
    clear_inventory()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
